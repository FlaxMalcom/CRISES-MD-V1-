const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
    const helpMessage = `
‎┏◆💎𝐂𝐑𝐈𝐒𝐄𝐒 𝐌𝐃 𝐕𝟏💎◆┓
‎┃⧎ 𝐇𝐞𝐥𝐥𝐨: *${settings.𝐠𝐫𝐞𝐞𝐭 || '𝐍𝐮𝐥𝐥'}*  
‎┃⧎ 𝐕𝐢𝐬𝐢𝐨𝐧: *${settings.version || '3.0.0'}*
‎┃⧎ 𝐎𝐰𝐧𝐞𝐫: *${settings.botOwner || '𝐅𝐥𝐚𝐱 𝐌𝐚𝐥𝐜𝐨𝐦 𝐓𝐞𝐜𝐡'}*
‎┃⧎ 𝐒𝐭𝐚𝐭𝐮𝐬: *𝐀𝐜𝐭𝐢𝐯𝐞💦*
‎┃⧎ 𝐌𝐨𝐝𝐞: *𝐏𝐮𝐛𝐥𝐢𝐜*
‎┃⧎ 𝐋𝐢𝐛𝐫𝐚𝐫𝐲: *𝐁𝐚𝐢𝐥𝐞𝐲𝐬*
‎┃⧎ 𝐏𝐫𝐢𝐟𝐢𝐱: *[•]*
‎┗━━━━━━━━━━━━━━━━┛

‎❖═━═══𖠁𐂃𖠁════━═❖

‎┏━◆𝐆𝐄𝐍𝐄𝐑𝐀𝐋 𝐌𝐄𝐍𝐔◆━┓
‎│❖ .help or .menu
‎│❖ .ping
‎│❖ .alive
‎│❖ .tts <text>
‎│❖ .owner
‎│❖ .joke
‎│❖ .quote
‎│❖ .fact
‎│❖ .weather <city>
‎│❖ .news
‎│❖ .attp <text>
‎│❖ .lyrics <song_title>
‎│❖ .8ball <question>
‎│❖ .groupinfo
‎│❖ .staff or 
‎│❖ .admins 
‎│❖ .vv
‎│❖ .trt <text> <lang>
‎│❖ .ss <link>
‎│❖ .jid
‎│❖ .url
‎┗━━━━━━━━━━━━━━━━┛ 

‎┏━━◆𝐀𝐃𝐌𝐈𝐃 𝐌𝐄𝐍𝐔◆━━┓
‎│❖ .ban @user
‎│❖ .promote @user
‎│❖ .demote @user
‎│❖ .mute <minutes>
‎│❖ .unmute
‎│❖ .delete or .del
‎│❖ .kick @user
‎│❖ .warnings @user
‎│❖ .warn @user
‎│❖ .antilink
‎│❖ .antibadword
‎│❖ .clear
‎│❖ .tag <message>
‎│❖ .tagall
‎│❖ .tagnotadmin
‎│❖ .hidetag <message>
‎│❖ .chatbot
‎│❖ .resetlink
‎│❖ .antitag <on/off>
‎│❖.welcome <on/off>
‎│❖ .goodbye <on/off>
‎│❖ .setgdesc <description>
‎│❖ .setgname <new name>
‎│❖ .setgpp (reply to image)
‎┗━━━━━━━━━━━━━━━━┛ 
 
‎┏━━◆𝐎𝐖𝐍𝐄𝐑 𝐂𝐎𝐌◆━━┓
‎│❖ .mode <public/private>
‎│❖ .clearsession
‎│❖ .antidelete
‎│❖ .cleartmp
‎│❖ .update
‎│❖ .settings
‎│❖ .setpp <reply to image>
‎│❖ .autoreact <on/off>
‎│❖ .autostatus <on/off>
‎│❖ .autostatus react <on/off>
‎│❖ .autotyping <on/off>
‎│❖ .autoread <on/off>
‎│❖ .anticall <on/off>
‎│❖ .pmblocker <on/off/status>
‎│❖ .pmblocker setmsg <text>
‎│❖ .setmention <reply to msg/media>
‎│❖ .mention <on/off>
‎┗━━━━━━━━━━━━━━━━┛ 

‎┏━◆𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐂𝐎𝐌𝐌◆━┓
‎│❖ .blur <image>
‎│❖ .simage <reply to sticker>
‎│❖ .sticker <reply to image>
‎│❖ .removebg
‎│❖ .remini
‎│❖ .crop <reply to image>
‎│❖ .tgsticker <Link>
‎│❖ .meme
‎│❖ .take <packname> 
‎│❖ .emojimix <emj1>+<emj2>
‎│❖ .igs <insta link>
‎│❖ .igsc <insta link>
‎┗━━━━━━━━━━━━━━━━┛ 

‎┏━◆𝐏𝐈𝐄𝐒 𝐂𝐎𝐌𝐌𝐀𝐍𝐃◆━┓
‎│❖ .pies <country>
‎│❖ .china 
‎│❖ .indonesia 
‎│❖ .japan 
‎│❖ .korea 
‎│❖ .hijab
‎┗━━━━━━━━━━━━━━━━┛  

‎┏━◆𝐆𝐀𝐌𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃◆┓
‎│❖ .tictactoe @user
‎│❖ .hangman
‎│❖ .guess <letter>
‎│❖ .trivia
‎│❖ .answer <answer>
‎│❖ .truth
‎│❖ .dare
‎┗━━━━━━━━━━━━━━━━┛  
 
‎┏━◆𝐀𝐈 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒◆━━┓
‎│❖ .gpt <question>
‎│❖ .gemini <question>
‎│❖ .imagine <prompt>
‎│❖ .flux <prompt>
‎│❖ .sora <prompt>
‎┗━━━━━━━━━━━━━━━━┛ 

‎┏━◆𝐅𝐔𝐍 𝐂𝐎𝐌𝐌𝐀𝐍𝐃◆━┓
‎│❖ .compliment @user
‎│❖ .insult @user
‎│❖ .flirt 
‎│❖ .shayari
‎│❖ .goodnight
‎│❖ .roseday
‎│❖ .character @user
‎│❖ .wasted @user
‎│❖ .ship @user
‎│❖ .simp @user
‎│❖ .stupid @user [text]
‎┗━━━━━━━━━━━━━━━━┛ 

‎┏━━◆𝐓𝐄𝐗𝐓 𝐌𝐀𝐊𝐄𝐑◆━━┓
‎│❖ .metallic <text>
‎│❖ .ice <text>
‎│❖ .snow <text>
‎│❖ .impressive <text>
‎│❖ .matrix <text>
‎│❖ .light <text>
‎│❖ .neon <text>
‎│❖ .devil <text>
‎│❖ .purple <text>
‎│❖ .thunder <text>
‎│❖ .leaves <text>
‎│❖ .1917 <text>
‎│❖ .arena <text>
‎│❖ .hacker <text>
‎│❖ .sand <text>
‎│❖ .blackpink <text>
‎│❖ .glitch <text>
‎│❖ .fire <text>
‎┗━━━━━━━━━━━━━━━━┛  

‎┏━━◆ 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃 ◆━━┓
‎│❖ .play <song_name>
‎│❖ .song <song_name>
‎│❖ .spotify <query>
‎│❖ .instagram <link>
‎│❖ .facebook <link>
‎│❖ .tiktok <link>
‎│❖ .video <song name>
‎│❖ .ytmp4 <Link>
‎┗━━━━━━━━━━━━━━━━┛ 



‎┏━━━◆𝐌𝐈𝐒𝐂 𝐂𝐎𝐌◆━━━┓
‎│❖ .heart
‎│❖ .horny
‎│❖ .circle
‎│❖ .lgbt
‎│❖ .lolice
‎│❖ .its-so-stupid
‎│❖ .namecard 
‎│❖ .oogway
‎│❖ .tweet
‎│❖ .ytcomment 
‎│❖ .comrade 
‎│❖ .gay 
‎│❖ .glass 
‎│❖ .jail 
‎│❖ .passed 
‎│❖ .triggered
‎┗━━━━━━━━━━━━━━━━┛ 


‎┏━━◆𝐀𝐍𝐈𝐌𝐄 𝐂𝐎𝐌𝐌◆━━┓
‎│❖ .neko
‎│❖ .waifu
‎│❖ .lol
‎│❖ .nom 
‎│❖ .poke 
‎│❖ .cry 
‎│❖ .kiss 
‎│❖ .pat 
‎│❖ .hug 
‎│❖ .wink 
‎│❖ .facepalm 
‎┗━━━━━━━━━━━━━━━━┛  

‎┏━━◆𝐆𝐈𝐓𝐇𝐔𝐁 𝐂𝐎𝐌◆━━┓
‎│❖ .git
‎│❖ .github
‎│❖ .sc
‎│❖ .script
‎│❖ .repo
‎┗━━━━━━━━━━━━━━━━┛  

💎𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐃 𝐁𝐘 𝐅𝐋𝐀𝐗 𝐌𝐀𝐋𝐂𝐎𝐌💎`;

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        
        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363386535738813@newsletter',
                        newsletterName: '𝐂𝐑𝐈𝐒𝐄𝐒 𝐌𝐃',
                        serverMessageId: -1
                    }
                }
            },{ quoted: message });
        } else {
            console.error('Bot image not found at:', imagePath);
            await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363386535738813@newsletter',
                        newsletterName: '𝐂𝐑𝐈𝐒𝐄𝐒 𝐌𝐃 𝐁𝐘 𝐅𝐋𝐀𝐗 𝐌𝐀𝐋𝐂𝐎𝐌',
                        serverMessageId: -1
                    } 
                }
            });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }
}

module.exports = helpCommand;
